# Documentaion

## [Usecases ➡](./usecase.md)

## [Synopsis ➡](./Synopsis.md)

## [Documentation Specification ➡](./doc-spec.md)

## [ERD ➡](./ER_diagram.md)
