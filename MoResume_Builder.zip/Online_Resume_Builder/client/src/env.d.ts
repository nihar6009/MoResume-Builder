/// <reference types="astro/client-image" />
